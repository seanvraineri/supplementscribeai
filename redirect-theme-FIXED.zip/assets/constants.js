// Theme constants
window.theme = window.theme || {};

window.theme.strings = {
  addToCart: 'Add to cart',
  soldOut: 'Sold out',
  unavailable: 'Unavailable'
};

window.theme.moneyFormat = '${{amount}}'; 